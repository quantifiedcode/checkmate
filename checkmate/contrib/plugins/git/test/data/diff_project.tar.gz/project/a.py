import foo
import bar
from foobar import *