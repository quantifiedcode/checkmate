import a

from bar import *
from foo import *
from zoo import *
from doo import *
