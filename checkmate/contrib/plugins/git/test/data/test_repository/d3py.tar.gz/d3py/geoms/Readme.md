How to Build a Geom
===================

1) subclass the Geom class

2) give the __init__ method the names of the columns of the data frame you want to use
